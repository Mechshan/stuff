.. _changelog:

Changelog
=========

`14.0.1.0.1`
------------

- change print_report_name (spaces removed)

`14.0.1.0.0`
------------

- Migrate to 14.0


